$(document).ready(function() {
  
    $('#logoutBtn').click(function () {
        
        console.log('Logout clicked');
    });

   
    $('#profileBtn').click(function () {
        
        console.log('Profile clicked');
    });


    $('#dashboardBtn').click(function () {
        
        console.log('Dashboard clicked');
    });

    
    $('#sellBtn').click(function () {
        
        window.location.href = 'sell.html';
        console.log('SELL button clicked');
    });

  
    $('#buyBtn').click(function () {
        
        window.location.href = 'buy.html';
        console.log('BUY button clicked');
    });

   
    $('#exploreBtn').click(function () {
        
        window.location.href = 'explore.html';
        console.log('EXPLORE button clicked');
    });
});
