
export function login() {
    var username = document.getElementById("email").value;
    var password = document.getElementById("password").value;
  
    
    auth
      .signInWithEmailAndPassword(username, password)
      .then((userCredential) => {
        // Successfully logged
  