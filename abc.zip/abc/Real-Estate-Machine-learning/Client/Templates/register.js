
function register() {
    var email = document.getElementById('email').value;
    var password = document.getElementById('password').value;

 
    var messageContainer = document.getElementById('registrationMessage');

    fetch('http://127.0.0.1:5000/register', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `email=${email}&password=${password}`,
    })
    .then(response => response.json())
    .then(data => {

        messageContainer.innerHTML = '';

 
        if (data.message) {
  
            var successMessage = document.createElement('div');
            successMessage.className = 'alert alert-success';
            successMessage.innerHTML = data.message;
            messageContainer.appendChild(successMessage);

            console.log('Redirecting to login.html...');

            
            window.location.href = './login.html';

        } else if (data.error) {
           
            var errorMessage = document.createElement('div');
            errorMessage.className = 'alert alert-danger';
            errorMessage.innerHTML = 'Registration failed. Error: ' + data.error;
            messageContainer.appendChild(errorMessage);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        
    });
}
